package com.sergegomis.practicaltest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PracticaltestApplicationTests {

	@Test
	void contextLoads() {
	}

}
